  #include <iostream>
      using namespace std;
       int main()
        {
          cout <<"Buenas Criaturitas del señor"<<endl;
          return 0;
        }

